import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { TeachersComponent } from './teachers.component';
import { TeachersRoutingModule } from './teachers-routing.module';
import { MaterialModule } from '../material-module';
import { ListComponent } from './components/list/list.component';

@NgModule({
  declarations: [TeachersComponent, ListComponent],
  imports: [
  			CommonModule,
  			MaterialModule,
   			TeachersRoutingModule]
})
export class TeachersModule { }
